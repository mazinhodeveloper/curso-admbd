<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UC2 Projeto</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding-top: 20px; /* Adjust for fixed navbar */
        }
        .container { 
            margin-bottom: 40px; 
        } 
        .jumbotron {
            padding: 2rem 1rem;
            margin-bottom: -1rem;
            background-color: #e9ecef;
            border-radius: .3rem;
        }
        .section-spacing {
            padding-top: 60px;
        }
        h2, h2 { 
            font-size: 1.6rem; 
        }
        pre {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
        }
        /* X-Small devices (portrait phones, less than 576px)
           No media query for `xs` since this is the default in Bootstrap */ 

        /* Small devices (landscape phones, 576px and up) */ 
        /* @media (min-width: 576px) { ul.navbar-nav li.nav-item { font-size: 0.9rem; } } */ 
        @media (min-width: 6px) { ul.navbar-nav li.nav-item { font-size: 0.9rem; } }

        /* Medium devices (tablets, 768px and up) */ 
        @media (min-width: 768px) { ul.navbar-nav li.nav-item { font-size: 0.9rem; } }

        /* Large devices (desktops, 992px and up) */ 
        @media (min-width: 992px) { ul.navbar-nav li.nav-item { font-size: 0.9rem; } }

        /* X-Large devices (large desktops, 1200px and up) */ 
        @media (min-width: 1200px) { ul.navbar-nav li.nav-item { font-size: 1rem; } }

        footer .container { margin-bottom: 0px; padding-bottom: 10px; font-size: 0.8rem; } 
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <a class="navbar-brand" href="#">PHP</a>
    </nav>

    <div class="container">

        <section id="banco-tabelas" class="section-spacing">
            <div class="card">
                <div class="card-header">
                    <h2>Biblioteca</h2>
                </div>
                <div class="card-body">
                    <?php
                        include_once 'config.php'; // Include the database connection file
                        /* 
                        
                        if($_SERVER['REQUEST_METHOD'] == 'POST') {
                            $name = "Someone Developer";
                            $email = "someonedeveloper@gmail.com"; 
                            $birth = "1988-05-08";
                            $INSERT = $CONNECTION->prepare("INSERT INTO usuarios (nome, email, data_nascimento) VALUES (?,?,?)");
                            $dados = [$name, $email, $birth];
                            if ($INSERT->execute($dados)) {  
                                echo "User $name included!";
                            } else {
                                echo "Can't insert!"; 
                            }
                        */
                        
                        if($_SERVER['REQUEST_METHOD'] == 'POST') {
                            $name = $_POST['nome'];
                            $email = $_POST['email']; 
                            $birth = $_POST['nascimento'];
                            $passw = $_POST['senha'];
                            $INSERT = $CONNECTION->prepare("INSERT INTO usuarios (nome, email, data_nascimento, senha) VALUES (?,?,?,?)");
                            $dados = [$name, $email, $birth, $passw];
                            
                            if ($INSERT->execute($dados)) {  
                                echo "User $name included!";
                            } else {
                                echo "Can't insert!"; 
                            }
                        } 

                        $SELECT = $CONNECTION->prepare("SELECT * FROM usuarios");
                        $SELECT->execute();
                        //$usuarios = $SELECT->fetch(PDO::FETCH_ASSOC);
                        $usuarios = $SELECT->fetchAll(PDO::FETCH_ASSOC);
                        //echo "<pre>";
                        //print_r($usuarios);
                        //echo "<p>This is a PHP script embedded in HTML.</p>";
                        //echo "</pre>"; 
                    ?>
                </div>
            </div>
        </section>
        <!--
        <section id="mer" class="section-spacing">
            <div class="card">
                <div class="card-header">
                    <h2>Modelo de Entidade Relacionamento (MER)</h2>
                </div>
                <div class="card-body">
                    <p>Projeto de Banco de Dados de E-commerce</p> 
                    <img src="images/LojaVirtual-1.svg" alt="Modelo de Entidade Relacionamento (MER) - E-commerce" width="100%">
                </div>
            </div>
        </section>
        -->
    </div>

    <div class="container">

                    <!-- --> 
<form class="needs-validation" novalidate> 
<div class="row g-3"> 
    <div class="col-sm-6"> 
        <label for="firstName" class="form-label">First name</label> 
        <input type="text" class="form-control" id="firstName" placeholder="" value="" required> 
        <div class="invalid-feedback">Valid first name is required.</div> 
    </div> 
    <div class="col-sm-6"> 
        <label for="lastName" class="form-label">Last name</label> 
        <input type="text" class="form-control" id="lastName" placeholder="" value="" required> 
        <div class="invalid-feedback">Valid last name is required.</div> 
    </div> 
<div class="col-12"> 
<label for="username" class="form-label">Username</label> 
<div class="input-group has-validation"> <span class="input-group-text">@</span> 
<input type="text" class="form-control" id="username" placeholder="Username" required> <div class="invalid-feedback">
Your username is required.
</div> </div> </div> 
<div class="col-12"> 
    <label for="email" class="form-label">Email <span class="text-body-secondary">(Optional)</span></label> <input type="email" class="form-control" id="email" placeholder="you@example.com"> 
    <div class="invalid-feedback">
Please enter a valid email address for shipping updates.
</div> </div> <div class="col-12"> <label for="address" class="form-label">Address</label> <input type="text" class="form-control" id="address" placeholder="1234 Main St" required> <div class="invalid-feedback">
Please enter your shipping address.
</div> </div> <div class="col-12"> <label for="address2" class="form-label">Address 2 <span class="text-body-secondary">(Optional)</span></label> <input type="text" class="form-control" id="address2" placeholder="Apartment or suite"> </div> <div class="col-md-5"> <label for="country" class="form-label">Country</label> <select class="form-select" id="country" required> <option value="">Choose...</option> <option>United States</option> </select> <div class="invalid-feedback">
Please select a valid country.
</div> </div> <div class="col-md-4"> <label for="state" class="form-label">State</label> <select class="form-select" id="state" required> <option value="">Choose...</option> <option>California</option> </select> <div class="invalid-feedback">
Please provide a valid state.
</div> </div> <div class="col-md-3"> <label for="zip" class="form-label">Zip</label> <input type="text" class="form-control" id="zip" placeholder="" required> <div class="invalid-feedback">
Zip code required.
</div> </div> </div> <hr class="my-4"> <div class="form-check"> <input type="checkbox" class="form-check-input" id="same-address"> <label class="form-check-label" for="same-address">Shipping address is the same as my billing address</label> </div> <div class="form-check"> <input type="checkbox" class="form-check-input" id="save-info"> <label class="form-check-label" for="save-info">Save this information for next time</label> </div> <hr class="my-4"> <h4 class="mb-3">Payment</h4> <div class="my-3"> <div class="form-check"> <input id="credit" name="paymentMethod" type="radio" class="form-check-input" checked required> <label class="form-check-label" for="credit">Credit card</label> </div> <div class="form-check"> <input id="debit" name="paymentMethod" type="radio" class="form-check-input" required> <label class="form-check-label" for="debit">Debit card</label> </div> <div class="form-check"> <input id="paypal" name="paymentMethod" type="radio" class="form-check-input" required> <label class="form-check-label" for="paypal">PayPal</label> </div> </div> <div class="row gy-3"> <div class="col-md-6"> <label for="cc-name" class="form-label">Name on card</label> <input type="text" class="form-control" id="cc-name" placeholder="" required> <small class="text-body-secondary">Full name as displayed on card</small> <div class="invalid-feedback">
Name on card is required
</div> </div> <div class="col-md-6"> <label for="cc-number" class="form-label">Credit card number</label> <input type="text" class="form-control" id="cc-number" placeholder="" required> <div class="invalid-feedback">
Credit card number is required
</div> </div> <div class="col-md-3"> <label for="cc-expiration" class="form-label">Expiration</label> <input type="text" class="form-control" id="cc-expiration" placeholder="" required> <div class="invalid-feedback">
Expiration date required
</div> </div> <div class="col-md-3"> <label for="cc-cvv" class="form-label">CVV</label> <input type="text" class="form-control" id="cc-cvv" placeholder="" required> <div class="invalid-feedback">
Security code required
</div> </div> </div> <hr class="my-4">  </form>
                    <!-- --> 

        <section id="banco-tabelas" class="section-spacing">
            <div class="card">
                <div class="card-header">
                    <h2>Formulário de cadastro</h2>
                </div>

                <div class="card-body">
                    <form class="needs-validation" novalidate method="post">
                        <div class="col-sm-12"> 
                            <label for="nome" class="form-label">First name</label> 
                            <input type="text" class="form-control" id="nome" name="nome" placeholder="" value="" required> 
                            <div class="invalid-feedback">Inserir um nome válido.</div> 
                        </div> 
                        <div class="col-sm-12"> 
                            <label for="email" class="form-label">Email</label> 
                            <input type="text" class="form-control" id="email" name="email" placeholder="you@example.com" value="" required> 
                            <div class="invalid-feedback">Inserir um email válido.</div> 
                        </div> 
                        <div class="col-sm-12"> 
                            <label for="nascimento" class="form-label">Data de nascimento</label> 
                            <input type="date" class="form-control" id="nascimento" name="nascimento" placeholder="" value="" required> 
                            <div class="invalid-feedback">Inserir uma data de nascimento válida.</div> 
                        </div> 
                        <div class="col-sm-12"> 
                            <label for="senha" class="form-label">Senha</label> 
                            <input type="password" class="form-control" id="senha" name="snha" placeholder="" value="" required> 
                            <div class="invalid-feedback">Inserir uma senha válida.</div> 
                        </div> 
                        <hr class="my-4"> 
                        <div class="col-sm-12"> 
                            <!-- <button type="submit">CADASTRAR</button> --> 
                            <button class="w-100 btn btn-primary btn-lg" type="submit">Cadastrar</button>
                        </div>
                    </form>
                </div>
            </div>
        </section>

        

        <section id="banco-tabelas" class="section-spacing">
            <div class="card">
                <div class="card-header">
                    <h2>Biblioteca</h2>
                </div>

                <div class="card-body">
                    <h2>Formulário de cadastro</h2>
                    <form class="needs-validation" novalidate method="post">
                        <div class="col-sm-12"> 
                            <label for="nome" class="form-label">First name</label> 
                            <input type="text" class="form-control" id="nome" name="nome" placeholder="" value="" required> 
                            <div class="invalid-feedback">Inserir um nome válido.</div> 
                        </div> 
                        <div class="col-sm-12"> 
                            <label for="email" class="form-label">Email</label> 
                            <input type="text" class="form-control" id="email" name="email" placeholder="you@example.com" value="" required> 
                            <div class="invalid-feedback">Inserir um email válido.</div> 
                        </div> 
                        <div class="col-sm-12"> 
                            <label for="nascimento" class="form-label">Data de nascimento</label> 
                            <input type="date" class="form-control" id="nascimento" name="nascimento" placeholder="" value="" required> 
                            <div class="invalid-feedback">Inserir uma data de nascimento válida.</div> 
                        </div> 
                        <div class="col-sm-12"> 
                            <label for="senha" class="form-label">Senha</label> 
                            <input type="password" class="form-control" id="senha" name="snha" placeholder="" value="" required> 
                            <div class="invalid-feedback">Inserir uma senha válida.</div> 
                        </div> 
                        <hr class="my-4"> 
                        <div class="col-sm-12"> 
                            <!-- <button type="submit">CADASTRAR</button> --> 
                            <button class="w-100 btn btn-primary btn-lg" type="submit">Cadastrar</button>
                        </div>
                    </form>
                </div>
                <div>
                    <h2>Cadastrados</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Nome</th>
                                <th>Email</th>
                                <th>Senha</th>
                                <th>Nascimento</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php 
                            foreach ($usuarios AS $user) { 
                          ?>
                            <!-- Essa parte será repetida para cada registro do banco -->
                            <tr>
                                <td><?=$user['id_usuario']?></td>
                                <td><?=$user['nome']?></td>
                                <td><?=$user['email']?></td>
                                <td><?=$user['data_nascimento']?></td>
                                <td><?=$user['senha']?></td>
                                <td><a href="#?id=">Editar</a> | <a href="#?id=">Deletar</a></td>
                            </tr>
                            <!-- fim repetição --> 
                          <?php
                            }
                          ?>
                        </tbody>
                    </table>
                </div>
                </div>
            </div>
        </section>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>