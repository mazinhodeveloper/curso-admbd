
# PHP - Connections and Connection management 
https://www.php.net/manual/en/pdo.connections.php 

# php pdo connection try catch exception
https://www.google.com/search?q=php+pdo+connection+try+catch+exception&rlz=1C1GCEA_enBR1170BR1170&oq=php+pdo+connection+try&gs_lcrp=EgZjaHJvbWUqBwgDECEYnwUyBggAEEUYOTIHCAEQIRifBTIHCAIQIRifBTIHCAMQIRifBdIBCTEwNzE2ajBqN6gCALACAA&sourceid=chrome&ie=UTF-8




